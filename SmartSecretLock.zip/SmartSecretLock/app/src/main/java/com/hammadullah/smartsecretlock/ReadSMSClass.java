package com.hammadullah.smartsecretlock;

import android.app.ActivityManager;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by HammadUllah on 1/25/17.
 */

public class ReadSMSClass extends BroadcastReceiver {

    DevicePolicyManager deviceManger;
    ComponentName compName;

    @Override
    public void onReceive(Context context, Intent intent) {

        Object[] pdus = (Object[])intent.getExtras().get("pdus");

        SmsMessage shortMessage = SmsMessage.createFromPdu((byte[]) pdus[0]);

        String message = shortMessage.getDisplayMessageBody();



         if (message.length() == 16 && message.charAt(11) == ' ')
         {
             String first_word = message.substring(0, 11);

             first_word = first_word.toLowerCase();

             String password = message.substring(12, 16);



             if (first_word.equals("lockmyphone"))
             {

                 deviceManger = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                 compName = new ComponentName(context, DeviceAdminSample.class);

                 boolean active = deviceManger.isAdminActive(compName);

                 if (active)
                 {
                     deviceManger.setPasswordQuality(compName, DevicePolicyManager.PASSWORD_QUALITY_NUMERIC);
                     boolean result = deviceManger.resetPassword(password, DevicePolicyManager.RESET_PASSWORD_REQUIRE_ENTRY);


                     if (result) {
                         deviceManger.lockNow();
                     }
                 }








             }

         }












    }



}
